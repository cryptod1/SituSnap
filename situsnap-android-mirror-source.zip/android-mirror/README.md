# SituSnap Android mirror

This is a separate Android package for side-by-side testing. Its application ID is
`uk.co.situsnap.mirror`, so installing it does not replace the existing SituSnap app
or share its app-private data.

The app bundles the trial-access HTML as `app/src/main/assets/index.html`. The
WebView uses the GitHub Pages origin as its base URL so existing API calls and
camera/file inputs keep the web build's origin behavior. It grants web geolocation
only to that exact origin and limits top-level navigation to the same host.

## Refresh the bundled page

Copy the approved trial build into the assets file before building:

```sh
cp ../SituSnap-index-trial-access.html app/src/main/assets/index.html
```

## Build

With JDK 17, Android SDK platform 35, and Gradle 8.9 installed:

```sh
gradle --no-daemon assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`. A
manual GitHub Actions workflow is included to build and upload that APK artifact.
The APK is debug-signed for testing; it is not a Play Store release.
