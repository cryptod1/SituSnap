plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "uk.co.situsnap.mirror"
    compileSdk = 35

    defaultConfig {
        applicationId = "uk.co.situsnap.mirror"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.1.1-mirror"
    }
}
